#include "Globals.hpp"

void Globals::Init()
{

}
