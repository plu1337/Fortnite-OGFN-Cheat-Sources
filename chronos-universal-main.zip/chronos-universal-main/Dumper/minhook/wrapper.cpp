#include "wrapper.h"

#include "minhook.h"

void MHWrapper::InitMH()
{
	//MH_Initialize
	MH_Initialize();
}

MHSTATUS WINAPI MHWrapper::CreateHook(LPVOID pTarget, LPVOID pDetour, LPVOID* ppOriginal)
{
	MH_CreateHook(pTarget, pDetour, ppOriginal);
	return MHW_OK;
}

void MHWrapper::RemoveHook(LPVOID pTarget)
{
	MH_RemoveHook(pTarget);
}

MHSTATUS WINAPI MHWrapper::EnableHook(LPVOID pTarget)
{
	MH_EnableHook(pTarget);
	return MHW_OK;
}

void MHWrapper::DisableHook(LPVOID pTarget)
{
	MH_DisableHook(pTarget);
}
