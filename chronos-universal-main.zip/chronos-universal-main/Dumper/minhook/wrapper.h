#pragma once

#include <Windows.h>

typedef enum MHSTATUS
{
    // Unknown error. Should not be returned.
    MHW_UNKNOWN = -1,

    // Successful.
    MHW_OK = 0,

    // MinHook is already initialized.
    MHW_ERROR_ALREADY_INITIALIZED,

    // MinHook is not initialized yet, or already uninitialized.
    MHW_ERROR_NOT_INITIALIZED,

    // The hook for the specified target function is already created.
    MHW_ERROR_ALREADY_CREATED,

    // The hook for the specified target function is not created yet.
    MHW_ERROR_NOT_CREATED,

    // The hook for the specified target function is already enabled.
    MHW_ERROR_ENABLED,

    // The hook for the specified target function is not enabled yet, or already
    // disabled.
    MHW_ERROR_DISABLED,

    // The specified pointer is invalid. It points the address of non-allocated
    // and/or non-executable region.
    MHW_ERROR_NOT_EXECUTABLE,

    // The specified target function cannot be hooked.
    MHW_ERROR_UNSUPPORTED_FUNCTION,

    // Failed to allocate memory.
    MHW_ERROR_MEMORY_ALLOC,

    // Failed to change the memory protection.
    MHW_ERROR_MEMORY_PROTECT,

    // The specified module is not loaded.
    MHW_ERROR_MODULE_NOT_FOUND,

    // The specified function is not found.
    MHW_ERROR_FUNCTION_NOT_FOUND
}
MHSTATUS;

namespace MHWrapper
{
	void InitMH();
    MHSTATUS WINAPI CreateHook(LPVOID pTarget, LPVOID pDetour, LPVOID* ppOriginal);
	void RemoveHook(LPVOID pTarget);
    MHSTATUS WINAPI EnableHook(LPVOID pTarget);
	void DisableHook(LPVOID pTarget);
}