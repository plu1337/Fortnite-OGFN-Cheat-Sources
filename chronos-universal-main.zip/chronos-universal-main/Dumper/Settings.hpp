#pragma once

namespace CheatSettings
{

}