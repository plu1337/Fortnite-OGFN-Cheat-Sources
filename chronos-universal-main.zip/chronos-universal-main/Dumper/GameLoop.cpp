#include "GameLoop.hpp"

#include <iostream>
#include <format>

#include "imgui/imgui.h"
#include "Offsets.h"
#include "Memory.hpp"
#include "UnrealObjects.h"
#include "UnrealTypes.h"
#include "Logger.hpp"
#include "FortFuncs.hpp"
#include "Globals.hpp"

auto ModuleBase = (uintptr_t)GetModuleHandleA(0);

void GameLoop::Run()
{
	try
	{
		
		auto DrawList = ImGui::GetBackgroundDrawList();
		if (!DrawList) return;

		auto GWorld = Mem::Read(ModuleBase + 0x5C80950);
		if (!GWorld) return;
		Log::Addr(GWorld);

		auto OwningGameInstance = Mem::Read(GWorld + Off::Fort::OwningGameInstance);
		if (!OwningGameInstance) return;
		Log::Addr(OwningGameInstance);

		auto LP = Mem::Read(OwningGameInstance + Off::Fort::LocalPlayers);
		if (!LP) return;
		Log::Addr(LP);

		auto LPController = Mem::Read(LP + Off::Fort::PlayerController);
		if (!LPController) return;
		Log::Addr(LPController);

		auto LPCamera = Mem::Read(LPController + Off::Fort::PlayerCameraManager);
		if (!LPCamera) return;
		Log::Addr(LPCamera);

		Globals::CamInfo = FortFuncs::GetCameraInfo(LPCamera);
		std::string temp1 = "Location - " + std::to_string(Globals::CamInfo.Location.X) + ", " + std::to_string(Globals::CamInfo.Location.Y) + ", " + std::to_string(Globals::CamInfo.Location.Z);
		std::string temp2 = "Rotation - " + std::to_string(Globals::CamInfo.Rotation.Pitch) + ", " + std::to_string(Globals::CamInfo.Rotation.Yaw) + ", " + std::to_string(Globals::CamInfo.Rotation.Roll);
		std::string temp3 = "FOV - " + std::to_string(Globals::CamInfo.FOV);

		Log::Msg(temp1);
		Log::Msg(temp2);
		Log::Msg(temp3);
		DrawList->AddText({ 50, 50 }, ImColor(255, 0, 0), temp1.c_str());
		DrawList->AddText({ 50, 75 }, ImColor(255, 0, 0), temp2.c_str());
		DrawList->AddText({ 50, 100 }, ImColor(255, 0, 0), temp3.c_str());

		//auto LPPawn = Mem::Read(LPController + Off::Fort::AcknowledgedPawn);

		/*uintptr_t LPRoot, LPWeapon = 0;
		if (LPPawn)
		{
			Log::Addr(LPPawn);

			LPRoot = Mem::Read(LPPawn + Off::Fort::RootComponent);
			if (LPRoot) Log::Addr(LPRoot);

			LPWeapon = Mem::Read(LPPawn + Off::Fort::CurrentWeapon);
			if (LPWeapon) Log::Addr(LPWeapon);
		}*/

		//auto Levels = Mem::Read(GWorld + Off::Fort::Levels);
		//auto LevelsNum = Mem::Read(GWorld + (Off::Fort::Levels + 0x8));
		//for (int i = 0; i < LevelsNum; i++)
		//{
		//	auto Level = Mem::Read(Levels + (i * 0x8));
		//	if (!Level) continue;
		//
		//	auto Actors = Mem::Read(Level + 0x98);
		//	auto ActorsNum = Mem::Read(Level + (0x98 + 0x8));
		//	std::cout << std::format("ActorsNum - {}", ActorsNum) << std::endl;
		//	/*for (int j = 0; j < ActorsNum; j++)
		//	{
		//		auto Actor = Mem::Read(Actors + (j * 0x8));
		//		if (!Actor) continue;
		//
		//		UEObject Obj((void*)Actor);
		//		if (Obj.IsA(EClassCastFlags::Pawn))
		//		{
		//			auto Pawn = Actor;
		//			if (!Actor) continue;
		//
		//			auto Mesh = Mem::Read(Pawn + Off::Fort::Mesh);
		//			if (!Mesh) return;
		//		}
		//	}*/
		//}
	}
	catch (...) {}
}