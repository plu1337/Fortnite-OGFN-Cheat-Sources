#pragma once

#include "Structs.hpp"

namespace Globals
{
	inline CameraInfo CamInfo;
	inline FVector2D CurrentResolution;

	void Init();
}