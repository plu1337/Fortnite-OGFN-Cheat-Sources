#pragma once

#include "UnrealTypes.h"
#include "Structs.hpp"

namespace FortFuncs
{
	FVector2D W2S(FVector WorldLocation);
	FVector GetSocketLocation(uintptr_t Mesh, FName InSocketName);
	void SetControlRotation(uintptr_t PlayerController, FRotator NewRotation);
	CameraInfo GetCameraInfo(uintptr_t CameraManager);
}