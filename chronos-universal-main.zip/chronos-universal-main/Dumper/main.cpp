#include <Windows.h>
#include <iostream>
#include <chrono>
#include <fstream>

#include "D3D.hpp"
#include "Generator.h"
#include "Memory.hpp"

enum class EFortToastType : uint8
{
        Default                        = 0,
        Subdued                        = 1,
        Impactful                      = 2,
        EFortToastType_MAX             = 3,
};

DWORD MainThread(HMODULE Module)
{
	AllocConsole();
	FILE* Dummy;
	freopen_s(&Dummy, "CONOUT$", "w", stdout);
	freopen_s(&Dummy, "CONIN$", "r", stdin);
  
	//Generator::Init();

	ObjectArray::Init();
	FName::Init();
	Off::Init();
	Off::InSDK::InitPE();

	//Generator::InitPredefinedMembers();
	//Generator::InitPredefinedFunctions();

	/*FString Name;
	FString Version;
	UEClass Kismet = ObjectArray::FindClassFast("KismetSystemLibrary");
	UEFunction GetGameName = Kismet.GetFunction("KismetSystemLibrary", "GetGameName");
	UEFunction GetEngineVersion = Kismet.GetFunction("KismetSystemLibrary", "GetEngineVersion");

	Kismet.ProcessEvent(GetGameName, &Name);
	Kismet.ProcessEvent(GetEngineVersion, &Version);

	Settings::GameName = Name.ToString();
	Settings::GameVersion = Version.ToString();*/

	Off::InitGame();
	D3D::InitHook();

	while (true)
	{
		if (GetAsyncKeyState(VK_F6) & 1)
		{
			//fclose(stdout);
			//if (Dummy) fclose(Dummy);
			//FreeConsole();

			FreeLibraryAndExitThread(Module, 0);
		}

		Sleep(100);
	}

	return 0;
}

BOOL APIENTRY DllMain(HMODULE hModule, DWORD reason, LPVOID lpReserved)
{
	switch (reason)
	{
	case DLL_PROCESS_ATTACH:
		CreateThread(0, 0, (LPTHREAD_START_ROUTINE)MainThread, hModule, 0, 0);
		break;
	}

	return TRUE;
}