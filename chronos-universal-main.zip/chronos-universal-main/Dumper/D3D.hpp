#pragma once

#include <Windows.h>

#include <d3d11.h>

namespace D3D
{
	inline bool bInit = false;

	typedef HRESULT(__stdcall* Present) (IDXGISwapChain* pSwapChain, UINT SyncInterval, UINT Flags);
	typedef LRESULT(CALLBACK* WNDPROC)(HWND, UINT, WPARAM, LPARAM);

	inline Present oPresent;
	inline HWND window = 0;
	inline WNDPROC oWndProc;
	inline ID3D11Device* pDevice = 0;
	inline ID3D11DeviceContext* pContext = 0;
	inline ID3D11RenderTargetView* mainRenderTargetView;

	void InitImGui();
	LRESULT WINAPI WndProc(const HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
	HRESULT WINAPI hkPresent(IDXGISwapChain* pSwapChain, UINT SyncInterval, UINT Flags);

	void InitHook();
	void RemoveHook();
	
}