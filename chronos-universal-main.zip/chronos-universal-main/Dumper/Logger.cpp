#include "Logger.hpp"

#include <iostream>
#include <format>

#define GetName(val) #val

void Log::Addr(uintptr_t Address)
{
	if (bShouldLog)
		std::cout << std::format("[ Chronos ] {} - {:#x}", GetName(Address), Address) << std::endl;
}

void Log::Msg(std::string Message)
{
	if (bShouldLog)
		std::cout << std::format("[ Chronos ] {}", Message) << std::endl;
}
