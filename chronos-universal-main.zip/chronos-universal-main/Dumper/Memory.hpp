#pragma once

#include <cstdint>

namespace Mem
{
	template<typename T> 
	inline T Read(uintptr_t address) {
		return *reinterpret_cast<T*>(address);
	}

	inline uintptr_t Read(uintptr_t address) {
		return *reinterpret_cast<uintptr_t*>(address);
	}

	template<typename T> 
	inline void Write(uintptr_t address, T value) {
		*reinterpret_cast<T*>(address) = value;
	}

	inline void* GetPtr(uintptr_t Address)
	{
		return Read<void*>(Address);
	}

	inline uintptr_t GetAddr(void* Ptr)
	{
		return (uintptr_t)Ptr;
	}
}