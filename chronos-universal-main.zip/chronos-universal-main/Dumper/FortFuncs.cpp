#include "FortFuncs.hpp"

#include "ObjectArray.h"
#include "NameArray.h"
#include "FortFuncs_params.hpp"
#include "Globals.hpp"

FVector2D FortFuncs::W2S(FVector WorldLocation)
{
	float SinPitch = sinf(Globals::CamInfo.Rotation.Pitch * (3.14159265358979323846f / 180.f));
	float CosPitch = cosf(Globals::CamInfo.Rotation.Pitch * (3.14159265358979323846f / 180.f));
	float SinYaw = sinf(Globals::CamInfo.Rotation.Yaw * (3.14159265358979323846f / 180.f));
	float CosYaw = cosf(Globals::CamInfo.Rotation.Yaw * (3.14159265358979323846f / 180.f));

	FVector AxisPitch = { CosPitch * CosYaw, CosPitch * SinYaw, SinPitch };
	FVector AxisYaw = { 0.f * SinPitch * CosYaw - 1.f * SinYaw, 0.f * SinPitch * SinYaw + 1.f * CosYaw, -0.f * CosPitch };
	FVector AxisRoll = { -(1.f * SinPitch * CosYaw + 0.f * SinYaw), CosYaw * 0.f - 1.f * SinPitch * SinYaw, 1.f * CosPitch };
	FVector Delta = WorldLocation - Globals::CamInfo.Location;
	FVector Transformed = {
		Delta.X * AxisPitch.X + Delta.Y * AxisPitch.Y + Delta.Z * AxisPitch.Z,
		Delta.X * AxisYaw.X + Delta.Y * AxisYaw.Y + Delta.Z * AxisYaw.Z,
		Delta.X * AxisRoll.X + Delta.Y * AxisRoll.Y + Delta.Z * AxisRoll.Z,
	};

	if (Transformed.X < 1.f)
		Transformed.X = 1.f;

	float TanFOV = tanf(Globals::CamInfo.FOV * .5f * 3.14159265358979323846f / 180.f);

	return 
	{
		Globals::CurrentResolution.X / 2.f + Transformed.Y * Globals::CurrentResolution.X / 2.f / TanFOV / Transformed.X,
		Globals::CurrentResolution.Y / 2.f - Transformed.Z * Globals::CurrentResolution.X / 2.f / TanFOV / Transformed.X
	};
}

FVector FortFuncs::GetSocketLocation(uintptr_t Mesh, FName InSocketName)
{
	UEFunction Func = nullptr;

	if (!Func)
		ObjectArray::FindObject<UEFunction>("Function Engine.SceneComponent.GetSocketLocation");

	FortFuncs::Params::GetSocketLocation Params;
	Params.InSocketName = InSocketName;

	if (Mesh)
	{
		UEObject Obj((void*)Mesh);
		Obj.ProcessEvent(Func, &Params);
		return Params.ReturnValue;
	}

	return { 0.f, 0.f, 0.f };
}

void FortFuncs::SetControlRotation(uintptr_t PlayerController, FRotator NewRotation)
{
	UEFunction Func = nullptr;

	if (!Func)
		Func = ObjectArray::FindObject<UEFunction>("Function Engine.Controller.SetControlRotation");

	FortFuncs::Params::SetControlRotation Params;
	Params.NewRotation = NewRotation;

	if (PlayerController)
	{
		UEObject Obj((void*)PlayerController);
		Obj.ProcessEvent(Func, &Params);
	}
}

CameraInfo FortFuncs::GetCameraInfo(uintptr_t CameraManager)
{
	UEFunction GetLocationFunc = ObjectArray::FindObjectFast<UEFunction>("Function Engine.PlayerCameraManager.GetCameraLocation");;
	UEFunction GetRotationFunc = ObjectArray::FindObjectFast<UEFunction>("Function Engine.PlayerCameraManager.GetCameraRotation");;
	UEFunction GetFOVFunc = ObjectArray::FindObjectFast<UEFunction>("Function Engine.PlayerCameraManager.GetFOVAngle");;

	if (!GetLocationFunc)
		ObjectArray::FindObjectFast<UEFunction>("Function Engine.PlayerCameraManager.GetCameraLocation");
	if (!GetRotationFunc)
		ObjectArray::FindObjectFast<UEFunction>("Function Engine.PlayerCameraManager.GetCameraRotation");
	if (!GetFOVFunc)
		ObjectArray::FindObjectFast<UEFunction>("Function Engine.PlayerCameraManager.GetFOVAngle");

	CameraInfo CamInfo;
	FortFuncs::Params::GetCameraLocation GetLocationParams;
	FortFuncs::Params::GetCameraRotation GetRotationParams;
	FortFuncs::Params::GetFOVAngle GetFOVParams;

	if (CameraManager)
	{
		UEObject Obj((void*)CameraManager);

		Obj.ProcessEvent(GetLocationFunc, &GetLocationParams);
		CamInfo.Location = GetLocationParams.ReturnValue;

		Obj.ProcessEvent(GetRotationFunc, &GetRotationParams);
		CamInfo.Rotation = GetRotationParams.ReturnValue;

		Obj.ProcessEvent(GetFOVFunc, &GetFOVParams);
		CamInfo.FOV = GetFOVParams.ReturnValue;

		return CamInfo;
	}

	return CameraInfo();
}




