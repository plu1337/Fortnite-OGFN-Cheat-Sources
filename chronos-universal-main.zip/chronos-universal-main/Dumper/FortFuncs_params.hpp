#pragma once

#include "Structs.hpp"
#include "Offsets.h"
#include "ObjectArray.h"
#include "OffsetFinder.h"

namespace FortFuncs
{
	namespace Params
	{
		struct GetSocketLocation
		{
		public:
			FName InSocketName;
			FVector ReturnValue;
		};

		struct SetControlRotation
		{
		public:
			FRotator NewRotation;
		};

		struct GetFOVAngle
		{
		public:
			float ReturnValue;
		};

		struct GetCameraLocation
		{
		public:
			FVector ReturnValue;
		};

		struct GetCameraRotation
		{
		public:
			FRotator ReturnValue;
		};


	}
}