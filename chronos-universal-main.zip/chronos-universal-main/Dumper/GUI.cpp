#include "GUI.hpp"

#include <string>
#include <format>
#include <vector>

#include "Offsets.h"
#include "imgui/imgui.h"

void GUI::Render()
{
	if (ImGui::Begin("Chronos Universal"))
	{
		for (int i = 0; i < Off::Fort::AllOffsets.size(); i++)
		{
			auto off = Off::Fort::AllOffsets[i];
			std::string Temp = std::format("{} - {:#x}", off.Name, off.Value);
			ImGui::Text(Temp.c_str());
		}

		ImGui::End();
	}
}
