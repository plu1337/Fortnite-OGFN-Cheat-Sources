#pragma once

#include <string>
#include <cstdint>

namespace Log
{
	void Addr(uintptr_t Address);
	void Msg(std::string Message);

	inline bool bShouldLog = false;
}