#pragma once

#include "imgui/imgui.h"

struct FVector
{
public:
	float X;
	float Y;
	float Z;

	bool IsEmpty()
	{
		if (X == 0 && Y == 0 && Z == 0)
			return true;

		return false;
	}

	inline FVector operator+(const FVector Other) const
	{
		return { X + Other.X, Y + Other.Y, Z + Other.Z };
	}

	inline FVector operator-(const FVector Other) const
	{
		return { X - Other.X, Y - Other.Y, Z - Other.Z };
	}
};

struct FVector2D
{
public:
	float X;
	float Y;

	bool IsEmpty() 
	{
		if (X == 0 && Y == 0)
			return true;

		return false;
	}
};

struct FRotator
{
public:
	float Pitch;
	float Yaw;
	float Roll;
};

struct CameraInfo
{
public:
	FRotator Rotation;
	FVector Location;
	float FOV;
};

