#pragma once

namespace GUI
{
	inline bool bIsOpen = true;
	inline int MenuKey = 0x2D; // insert

	void Render();
}